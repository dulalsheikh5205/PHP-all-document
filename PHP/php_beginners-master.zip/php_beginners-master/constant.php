<?php

// $max_width = 980;

// define("MAX_WIDTH", 980);
// echo MAX_WIDTH;

echo PHP_EOL;

 // can't change the value
// MAX_WIDTH = MAX_WIDTH + 1;
// echo MAX_WIDTH;


 // can't even redefine it
// define( "MAX_WIDTH", 981 );
// echo MAX_WIDTH;
