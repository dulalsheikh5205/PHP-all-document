<?php
/**
 * 11.02.2023
 * ===========
 * fibonacci
 * recursive function
 * continue
 * break
 * constant
 * nested for loop
 *
 *
 * */

/**
 * 12.02.2023
 * ===========
 * array
 * Array Functions
 * Different types of Array:
 * ======> Indexed Array,
 * ======> Associative Array,
 * ======> Multidimensional Array(
 * =============>two dimensional,
 * =============>three dimensional)
 * print_r() Function
 * For each Loop
 * Nested Foreach Loop
 * infinite for loop
 * */

/**
 * 13.02.2023
 * ===========
 * 1.Variable scope
 * 2.Input validation
 * 3.Debugging tools in php
 * 4.Anonymous Function
 * 5.Function Overloading
 * */

/**
 * 14.02.2023
 * ==========
 * Commonly used array functions
 * ==============================
 * array_key_exists,array_push,array_pop,array_shift,array_unshift,array_combine,array_merge,array_unique,array_intersect,array_diff,array_slice,array_reverse,sort,rsort,usort,array_search,in_array,count,implode,explode, array_map
 * */

/**
 * 15.02.2023
 * ===========
 * Commonly used string functions
 * ==============================
 * strlen substr strpos str_replace trim strtoupper strtolower ucfirst ucwords strrev str_pad str_repeat str_split explode implode addslashes stripslashes htmlentities html_entity_decode strip_tags
 
 * */ 

/**
 * 16.02.2023
 * Commonly used Math Functions
 * =============================
 * abs() ceil() floor() round()max() min() sqrt() pow() exp() log() log10() rand() mt_rand() pi() deg2rad() rad2deg() sin() cos() tan() asin() 
 * 
 * ✔✔✔✔❤❤❤🐱‍🚀❤❤❤🐱‍🚀🐱‍🚀👀👀👀👀 
 * 
 * Commonly Used Date/Time Functions
 * date() gmdate() strtotime() time() mktime() getdate() checkdate() date_default_timezone_set()date_default_timezone_get() date_sunrise() date_sunset() date_sun_info() strftime()gmstrftime() date_create()date_create_from_format() date_format() date_modify() date_diff() date_timezone_get()
 * 
 * 
 * */ 

/**
 * 18.02.2023
 * Review of 
 * Array Functions
 * String Functions
 * Date/Time Functions
 * Math Functions 
 * */ 

/**
 * 19.02.2023
 * super global variables
 * search project for explaining super global variable get,post, request
 * 
 * */ 

/**
 * 20.02.2023 
 * Four Projects using super global variables:
 * 1. Auth project
 * 2.file submit project
 * 3.form submit project
 * 4.server client info * 
 * */ 

/**
 * isset
 * isempty
 * header
 * Three Projects:
 * 1.string tool
 * 2.random password generator
 * 3.password generator
 * 4.login
 * 
 * 
 * 
 * */  