<?php
function sum(int $x=5,int $y=5,int $z=5):int{
    return $x+$y+$z ;
   
}

$value1=sum(1000,2000,3000);
echo $value1;


// function sub($m){
//     echo $m-500;
// }

// sub($value1);
