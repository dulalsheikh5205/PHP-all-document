<?php

function constan(){

    define( "GREETING", "Welcome to W3Schools.com!" );
    echo GREETING;
}

constan();