<?php
namespace CloudStorage\Mail;
class Mailer {
    public function getMail() {
        echo "Get Mail\n";
    }
}