<?php
namespace CloudStorage\FileSystem;
class Scanner {
    public function scan() {
        echo "Scanning\n";
    }
}