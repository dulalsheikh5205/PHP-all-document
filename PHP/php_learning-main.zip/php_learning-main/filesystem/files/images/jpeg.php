<?php
namespace CloudStorage\FileSystem\Files\Images;
class Jpeg {
    public function getName() {
        echo "Jpeg images\n";
    }
}