<?php
namespace CloudStorage\FileSystem\Files\Contracts;
class ImageContracts {
    public function getDimension() {
        echo "Dimension\n";
    }
}